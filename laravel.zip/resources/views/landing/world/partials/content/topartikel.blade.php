<div class="sidebar-widget-area">
   <h5 class="title">Top Artikel</h5>
   <div class="widget-content">

      <div class="single-blog-post post-style-2 d-flex align-items-center widget-post">

         <div class="post-thumbnail">
            <img src="assets/Landing/world/img/blog-img/b11.jpg" alt="">
         </div>

         <div class="post-content">
            <a href="#" class="headline">
               <h5 class="mb-0">How Did van Gogh’s Turbulent Mind Depict One of the Most</h5>
            </a>
         </div>
      </div>

      <div class="single-blog-post post-style-2 d-flex align-items-center widget-post">

         <div class="post-thumbnail">
            <img src="assets/Landing/world/img/blog-img/b13.jpg" alt="">
         </div>

         <div class="post-content">
            <a href="#" class="headline">
               <h5 class="mb-0">How Did van Gogh’s Turbulent Mind Depict One of the Most</h5>
            </a>
         </div>
      </div>

      <div class="single-blog-post post-style-2 d-flex align-items-center widget-post">

         <div class="post-thumbnail">
            <img src="assets/Landing/world/img/blog-img/b14.jpg" alt="">
         </div>

         <div class="post-content">
            <a href="#" class="headline">
               <h5 class="mb-0">How Did van Gogh’s Turbulent Mind Depict One of the Most</h5>
            </a>
         </div>
      </div>

      <div class="single-blog-post post-style-2 d-flex align-items-center widget-post">

         <div class="post-thumbnail">
            <img src="assets/Landing/world/img/blog-img/b10.jpg" alt="">
         </div>

         <div class="post-content">
            <a href="#" class="headline">
               <h5 class="mb-0">How Did van Gogh’s Turbulent Mind Depict One of the Most</h5>
            </a>
         </div>
      </div>

      <div class="single-blog-post post-style-2 d-flex align-items-center widget-post">

         <div class="post-thumbnail">
            <img src="assets/Landing/world/img/blog-img/b12.jpg" alt="">
         </div>

         <div class="post-content">
            <a href="#" class="headline">
               <h5 class="mb-0">How Did van Gogh’s Turbulent Mind Depict One of the Most</h5>
            </a>
         </div>
      </div>
   </div>
</div>