<div class="sidebar-widget-area">
   <h5 class="title">Stay Connected</h5>
   <div class="widget-content">
      <div class="social-area d-flex justify-content-between">
         <a href="#" class="social-facebook"><i class="fa fa-facebook"></i></a>
         <a href="#" class="social-twitter"><i class="fa fa-twitter"></i></a>
         <a href="#" class="social-youtube"><i class="fa fa-youtube-play"></i></a>
         <a href="#" class="social-instagram"><i class="fa fa-instagram"></i></a>
         <a href="#" class="social-whatsapp"><i class="fa fa-whatsapp"></i></a>
      </div>
   </div>
</div>