<div class="sidebar-widget-area">
   <h5 class="title">About World</h5>
   <div class="widget-content">
      <p>
         REAN (Rumah Edukasi Anti Narkoba) mengajak generasi milenial dan generasi Z dalam berkarya yang bersih dari Narkotika. REAN.ID merupakan media informasi, edukasi dan sumber informasi dan edukasi yang dikemas dalam bentuk muda inovasi dengan tujuan sebagai jejaring belajar, berbagi cerita dan inspirasi dalam mengekspresikan karya, menggali potensi dan membangun kepercayaan diri guna memperkuat citra remaja yang gemar mencoba hal baru, Yang mana Informasi dan edukasi ini difokuskan dalam pembuatan konten yang berliterasi di bidang pencegahan narkoba.
      </p>
   </div>
</div>