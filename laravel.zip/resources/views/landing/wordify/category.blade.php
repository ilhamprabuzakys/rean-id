<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from preview.colorlib.com/theme/meranda/categories.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Jun 2023 05:47:34 GMT -->
<head>
<title>Meranda &mdash; Website Template by Colorlib</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="../../../fonts.googleapis.com/css25fc.css?family=B612+Mono|Cabin:400,700&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="fonts/icomoon/style.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css">
<link rel="stylesheet" href="css/bootstrap-datepicker.css">
<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
<link rel="stylesheet" href="css/aos.css">
<link href="css/jquery.mb.YTPlayer.min.css" media="all" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/style.css">
<script nonce="d78ffdf4-04ba-48b6-a111-d1a60afd4969">(function(w,d){!function(dK,dL,dM,dN){dK[dM]=dK[dM]||{};dK[dM].executed=[];dK.zaraz={deferred:[],listeners:[]};dK.zaraz.q=[];dK.zaraz._f=function(dO){return function(){var dP=Array.prototype.slice.call(arguments);dK.zaraz.q.push({m:dO,a:dP})}};for(const dQ of["track","set","debug"])dK.zaraz[dQ]=dK.zaraz._f(dQ);dK.zaraz.init=()=>{var dR=dL.getElementsByTagName(dN)[0],dS=dL.createElement(dN),dT=dL.getElementsByTagName("title")[0];dT&&(dK[dM].t=dL.getElementsByTagName("title")[0].text);dK[dM].x=Math.random();dK[dM].w=dK.screen.width;dK[dM].h=dK.screen.height;dK[dM].j=dK.innerHeight;dK[dM].e=dK.innerWidth;dK[dM].l=dK.location.href;dK[dM].r=dL.referrer;dK[dM].k=dK.screen.colorDepth;dK[dM].n=dL.characterSet;dK[dM].o=(new Date).getTimezoneOffset();if(dK.dataLayer)for(const dX of Object.entries(Object.entries(dataLayer).reduce(((dY,dZ)=>({...dY[1],...dZ[1]})),{})))zaraz.set(dX[0],dX[1],{scope:"page"});dK[dM].q=[];for(;dK.zaraz.q.length;){const d_=dK.zaraz.q.shift();dK[dM].q.push(d_)}dS.defer=!0;for(const ea of[localStorage,sessionStorage])Object.keys(ea||{}).filter((ec=>ec.startsWith("_zaraz_"))).forEach((eb=>{try{dK[dM]["z_"+eb.slice(7)]=JSON.parse(ea.getItem(eb))}catch{dK[dM]["z_"+eb.slice(7)]=ea.getItem(eb)}}));dS.referrerPolicy="origin";dS.src="../../cdn-cgi/zaraz/sd0d9.js?z="+btoa(encodeURIComponent(JSON.stringify(dK[dM])));dR.parentNode.insertBefore(dS,dR)};["complete","interactive"].includes(dL.readyState)?zaraz.init():dK.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,"zarazData","script");})(window,document);</script></head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
<div class="site-wrap">
<div class="site-mobile-menu site-navbar-target">
<div class="site-mobile-menu-header">
<div class="site-mobile-menu-close mt-3">
<span class="icon-close2 js-menu-toggle"></span>
</div>
</div>
<div class="site-mobile-menu-body"></div>
</div>
<div class="header-top">
<div class="container">
<div class="row align-items-center">
<div class="col-12 col-lg-6 d-flex">
<a href="index.html" class="site-logo">
Meranda
</a>
<a href="#" class="ml-auto d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a>
</div>
<div class="col-12 col-lg-6 ml-auto d-flex">
<div class="ml-md-auto top-social d-none d-lg-inline-block">
<a href="#" class="d-inline-block p-3"><span class="icon-facebook"></span></a>
<a href="#" class="d-inline-block p-3"><span class="icon-twitter"></span></a>
<a href="#" class="d-inline-block p-3"><span class="icon-instagram"></span></a>
</div>
<form action="#" class="search-form d-inline-block">
<div class="d-flex">
<input type="email" class="form-control" placeholder="Search...">
<button type="submit" class="btn btn-secondary"><span class="icon-search"></span></button>
</div>
</form>
</div>
<div class="col-6 d-block d-lg-none text-right">
</div>
</div>
</div>
<div class="site-navbar py-2 js-sticky-header site-navbar-target d-none pl-0 d-lg-block" role="banner">
<div class="container">
<div class="d-flex align-items-center">
<div class="mr-auto">
<nav class="site-navigation position-relative text-right" role="navigation">
<ul class="site-menu main-menu js-clone-nav mr-auto d-none pl-0 d-lg-block">
<li class="active">
<a href="index.html" class="nav-link text-left">Home</a>
</li>
<li>
<a href="categories.html" class="nav-link text-left">Categories</a>
</li>
<li>
<a href="categories.html" class="nav-link text-left">Politics</a>
</li>
<li>
<a href="categories.html" class="nav-link text-left">Business</a>
</li>
<li>
<a href="categories.html" class="nav-link text-left">Health</a>
</li>
<li><a href="categories.html" class="nav-link text-left">Design</a></li>
<li>
<a href="categories.html" class="nav-link text-left">Sport</a>
</li>
 <li><a href="contact.html" class="nav-link text-left">Contact</a></li>
</ul>
</nav>
</div>
</div>
</div>
</div>
</div>
<div class="site-section">
<div class="container">
<div class="row">
<div class="col-lg-9">
<div class="section-title">
<span class="caption d-block small">Categories</span>
<h2>Politics</h2>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_4.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_3.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_1.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_4.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_3.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_1.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_4.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_3.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="post-entry-2 d-flex">
<div class="thumbnail order-md-2" style="background-image: url('images/img_h_1.jpg')"></div>
<div class="contents order-md-1 pl-0">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi temporibus praesentium neque, voluptatum quam quibusdam.</p>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
</div>
<div class="col-lg-3">
<div class="section-title">
 <h2>Popular Posts</h2>
</div>
<div class="trend-entry d-flex">
<div class="number align-self-start">01</div>
<div class="trend-contents">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="trend-entry d-flex">
<div class="number align-self-start">02</div>
<div class="trend-contents">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="trend-entry d-flex">
<div class="number align-self-start">03</div>
<div class="trend-contents">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<div class="trend-entry d-flex pl-0">
<div class="number align-self-start">04</div>
<div class="trend-contents">
<h2><a href="blog-single.html">News Needs to Meet Its Audiences Where They Are</a></h2>
<div class="post-meta">
<span class="d-block"><a href="#">Dave Rogers</a> in <a href="#">News</a></span>
<span class="date-read">Jun 14 <span class="mx-1">&bullet;</span> 3 min read <span class="icon-star2"></span></span>
</div>
</div>
</div>
<p>
<a href="#" class="more">See All Popular <span class="icon-keyboard_arrow_right"></span></a>
</p>
</div>
</div>
<div class="row">
<div class="col-lg-6">
<ul class="custom-pagination list-unstyled">
<li><a href="#">1</a></li>
<li class="active">2</li>
<li><a href="#">3</a></li>
<li><a href="#">4</a></li>
</ul>
</div>
</div>
</div>
</div>
<div class="site-section subscribe bg-light">
<div class="container">
<form action="#" class="row align-items-center">
<div class="col-md-5 mr-auto">
<h2>Newsletter Subcribe</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis aspernatur ut at quae omnis pariatur obcaecati possimus nisi ea iste!</p>
</div>
<div class="col-md-6 ml-auto">
<div class="d-flex">
<input type="email" class="form-control" placeholder="Enter your email">
<button type="submit" class="btn btn-secondary"><span class="icon-paper-plane"></span></button>
</div>
</div>
</form>
</div>
</div>
<div class="footer">
<div class="container">
<div class="row">
<div class="col-12">
<div class="copyright">
<p>

Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a>

</p>
</div>
</div>
</div>
</div>
</div>
</div>


<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" /><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15" /></svg></div>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.countdown.min.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.fancybox.min.js"></script>
<script src="js/jquery.sticky.js"></script>
<script src="js/jquery.mb.YTPlayer.min.js"></script>
<script src="js/main.js"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v52afc6f149f6479b8c77fa569edb01181681764108816" integrity="sha512-jGCTpDpBAYDGNYR5ztKt4BQPGef1P0giN6ZGVUi835kFF88FOmmn8jBQWNgrNd8g/Yu421NdgWhwQoaOPFflDw==" data-cf-beacon='{"rayId":"7ddb64a68ede87d8","version":"2023.4.0","b":1,"token":"cd0b4b3a733644fc843ef0b185f98241","si":100}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from preview.colorlib.com/theme/meranda/categories.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 27 Jun 2023 05:47:34 GMT -->
</html>