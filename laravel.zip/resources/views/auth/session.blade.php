<div class="my-2">
@include('components.session')
</div>