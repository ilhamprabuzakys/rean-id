<!doctype html>
<html lang="en">

<head>
   <meta charset="utf-8" />
   <title>{{ $title . ' - ' . config('app.name') }}</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="csrf-token" content="{{ csrf_token() }}">
   <meta content="Mutlipurpose App" name="description" />
   <meta content="Multipurpose App" name="ilhamprabuzakys" />
   <!-- App favicon -->
   <link rel="shortcut icon" href="{{ asset('assets/img/rean-berwarna-logo-saja.png') }}">

   <!-- Bootstrap Css -->
   <link href="{{ asset('assets/borex/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" id="bootstrap-style" />
   <!-- Icons Css -->
   <link href="{{ asset('assets/borex/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
   {{-- Box Icons Css --}}
   <link rel="stylesheet" href="{{ asset('assets/borex/libs/box-icons/css/boxicons.min.css') }}">

   {{-- Style CSS --}}
   <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
   <!-- App Css-->
   <link href="{{ asset('assets/borex/css/app.min.css') }}" rel="stylesheet" type="text/css" id="app-style" />
   {{-- <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" defer></script>
   <script>
      window.OneSignal = window.OneSignal || [];
      OneSignal.push(function() {
         OneSignal.init({
            appId: "bc7f7242-c743-4830-a3c9-0eed3497dfaf",
         });
      });
   </script> --}}
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw=="
   crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   @stack('style')
   @stack('head')
   {{-- @vite('resources/css/app.css') --}}
</head>


<body data-sidebar="dark" data-sidebar-size="sm" class="sidebar-enable">

   @php
      $postsCount = cache()->remember('postsCount', now()->addDays(1), function () {
         if (auth()->user()->role == 'member') {
            return App\Models\Post::where('user_id', auth()->user()->id)->get()->count();
         } else {
            return App\Models\Post::count();
         }
      });

      $categoriesCount = cache()->remember('categoriesCount', now()->addDays(1), function () {
          return App\Models\Category::count();
      });
      
      $tagsCount = cache()->remember('tagsCount', now()->addDays(1), function () {
          return App\Models\Tag::count();
      });

      $usersCount = cache()->remember('usersCount', now()->addDays(1), function () {
          return App\Models\User::count();
      });
   @endphp
   <!-- <body data-layout="horizontal"> -->


   <!-- Begin page -->
   <div id="layout-wrapper">


      @include('dashboard-borex.layouts.components.header')
      <!-- ========== Left Sidebar Start ========== -->
      <div class="vertical-menu">

         <!-- LOGO -->
         <div class="navbar-brand-box">
            <a href="{{ route('dashboard') }}" class="logo logo-light d-flex justify-content-start ">
               <span class="logo-lg ms-5">
                  <img src="{{ asset('assets/img/rean-hitam-putiih.png') }}" alt="" height="22px">
               </span>
               <span class="logo-sm">
                  <img src="{{ asset('assets/img/rean-berwarna-logo-saja2.png') }}" alt="" height="22px">
               </span>
            </a>
         </div>

         <button type="button" class="btn btn-sm px-3 header-item vertical-menu-btn topnav-hamburger">
            <div class="hamburger-icon">
               <span></span>
               <span></span>
               <span></span>
            </div>
         </button>

         <div data-simplebar class="sidebar-menu-scroll">

            <!--- Sidemenu -->
            @include('dashboard-borex.layouts.components.sidebar')
            <!-- Sidebar -->

            {{-- <div class="p-3 px-4 sidebar-footer">
                        <p class="mb-1 main-title"><script>document.write(new Date().getFullYear())</script> &copy; Borex.</p>
                        <p class="mb-0">Design & Develop by Themesbrand</p>
                    </div> --}}
         </div>
      </div>
      <!-- Left Sidebar End -->
      @include('dashboard-borex.layouts.components.sidebar-end')

      <!-- ============================================================== -->
      <!-- Start right Content here -->
      <!-- ============================================================== -->
      <div class="main-content">
         <div class="page-content">
            <div class="container-fluid" id="app">
               @include('dashboard-borex.components.session')

               @yield('content')
            </div>
            <!-- container-fluid -->
         </div>
         <!-- End Page-content -->

         <footer class="footer">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-sm-12">
                     <script>
                        document.write(new Date().getFullYear())
                     </script> &copy; Borex. Design & Develop by Themesbrand
                  </div>
               </div>
            </div>
         </footer>
      </div>
      <!-- end main content-->

   </div>
   <!-- END layout-wrapper -->

   <!-- Right Sidebar -->
   @include('dashboard-borex.layouts.components.customizer')
   <!-- /Right-bar -->

   <!-- Right bar overlay-->
   <div class="rightbar-overlay"></div>

   <!-- chat offcanvas -->
   <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasActivity" aria-labelledby="offcanvasActivityLabel">
      <div class="offcanvas-header border-bottom">
         <h5 id="offcanvasActivityLabel">Offcanvas right</h5>
         <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
         ...
      </div>
   </div>

   @include('sweetalert::alert')
   @stack('modal')
   {{-- <div id="preloader"></div> --}}

   <!-- JAVASCRIPT -->
   <script src="{{ asset('assets/borex/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
   <script src="{{ asset('assets/borex/libs/metismenujs/metismenujs.min.js') }}"></script>
   <script src="{{ asset('assets/borex/libs/simplebar/simplebar.min.js') }}"></script>
   <script src="{{ asset('assets/borex/libs/eva-icons/eva.min.js') }}"></script>

   @stack('scripts')

   {{-- @vite('resources/js/app.js') --}}
   {{-- Jquery --}}
   <script src="{{ asset('assets/js/script.js') }}"></script>
   <script src="{{ asset('assets/borex/js/app.js') }}"></script>

</body>

</html>
