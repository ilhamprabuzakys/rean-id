<div class="footer">
   <div class="container">
      <div class="row">
         <div class="col-12">
            <div class="copyright">
               <p>

                  Copyright &copy;
                  <script>
                     document.write(new Date().getFullYear());
                  </script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://rean.bnn.go.id/"
                     target="_blank">Rean</a>

               </p>
            </div>
         </div>
      </div>
   </div>
</div><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/partials/footer.blade.php ENDPATH**/ ?>