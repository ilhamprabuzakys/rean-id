<!doctype html>
<html lang="en">

<head>
   <meta charset="utf-8" />
   <title><?php echo e($title . ' - ' . config('app.name')); ?></title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <meta content="Mutlipurpose App" name="description" />
   <meta content="Multipurpose App" name="ilhamprabuzakys" />
   <!-- App favicon -->
   <link rel="shortcut icon" href="<?php echo e(asset('assets/img/rean-berwarna-logo-saja.png')); ?>">

   <!-- Bootstrap Css -->
   <link href="<?php echo e(asset('assets/borex/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap-style" />
   <!-- Icons Css -->
   <link href="<?php echo e(asset('assets/borex/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
   
   <link rel="stylesheet" href="<?php echo e(asset('assets/borex/libs/box-icons/css/boxicons.min.css')); ?>">

   
   <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
   <!-- App Css-->
   <link href="<?php echo e(asset('assets/borex/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />
   
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw=="
   crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   <?php echo $__env->yieldPushContent('style'); ?>
   <?php echo $__env->yieldPushContent('head'); ?>
   
</head>


<body data-sidebar="dark" data-sidebar-size="sm" class="sidebar-enable">

   <?php
      $postsCount = cache()->remember('postsCount', now()->addDays(1), function () {
         if (auth()->user()->role == 'member') {
            return App\Models\Post::where('user_id', auth()->user()->id)->get()->count();
         } else {
            return App\Models\Post::count();
         }
      });

      $categoriesCount = cache()->remember('categoriesCount', now()->addDays(1), function () {
          return App\Models\Category::count();
      });
      
      $tagsCount = cache()->remember('tagsCount', now()->addDays(1), function () {
          return App\Models\Tag::count();
      });

      $usersCount = cache()->remember('usersCount', now()->addDays(1), function () {
          return App\Models\User::count();
      });
   ?>
   <!-- <body data-layout="horizontal"> -->


   <!-- Begin page -->
   <div id="layout-wrapper">


      <?php echo $__env->make('dashboard-borex.layouts.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- ========== Left Sidebar Start ========== -->
      <div class="vertical-menu">

         <!-- LOGO -->
         <div class="navbar-brand-box">
            <a href="<?php echo e(route('dashboard')); ?>" class="logo logo-light d-flex justify-content-start ">
               <span class="logo-lg ms-5">
                  <img src="<?php echo e(asset('assets/img/rean-hitam-putiih.png')); ?>" alt="" height="22px">
               </span>
               <span class="logo-sm">
                  <img src="<?php echo e(asset('assets/img/rean-berwarna-logo-saja2.png')); ?>" alt="" height="22px">
               </span>
            </a>
         </div>

         <button type="button" class="btn btn-sm px-3 header-item vertical-menu-btn topnav-hamburger">
            <div class="hamburger-icon">
               <span></span>
               <span></span>
               <span></span>
            </div>
         </button>

         <div data-simplebar class="sidebar-menu-scroll">

            <!--- Sidemenu -->
            <?php echo $__env->make('dashboard-borex.layouts.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Sidebar -->

            
         </div>
      </div>
      <!-- Left Sidebar End -->
      <?php echo $__env->make('dashboard-borex.layouts.components.sidebar-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- ============================================================== -->
      <!-- Start right Content here -->
      <!-- ============================================================== -->
      <div class="main-content">
         <div class="page-content">
            <div class="container-fluid" id="app">
               <?php echo $__env->make('dashboard-borex.components.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

               <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- container-fluid -->
         </div>
         <!-- End Page-content -->

         <footer class="footer">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-sm-12">
                     <script>
                        document.write(new Date().getFullYear())
                     </script> &copy; Borex. Design & Develop by Themesbrand
                  </div>
               </div>
            </div>
         </footer>
      </div>
      <!-- end main content-->

   </div>
   <!-- END layout-wrapper -->

   <!-- Right Sidebar -->
   <?php echo $__env->make('dashboard-borex.layouts.components.customizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- /Right-bar -->

   <!-- Right bar overlay-->
   <div class="rightbar-overlay"></div>

   <!-- chat offcanvas -->
   <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasActivity" aria-labelledby="offcanvasActivityLabel">
      <div class="offcanvas-header border-bottom">
         <h5 id="offcanvasActivityLabel">Offcanvas right</h5>
         <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
         ...
      </div>
   </div>

   <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldPushContent('modal'); ?>
   

   <!-- JAVASCRIPT -->
   <script src="<?php echo e(asset('assets/borex/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/borex/libs/metismenujs/metismenujs.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/borex/libs/simplebar/simplebar.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/borex/libs/eva-icons/eva.min.js')); ?>"></script>

   <?php echo $__env->yieldPushContent('scripts'); ?>

   
   
   <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/borex/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/layouts/app.blade.php ENDPATH**/ ?>