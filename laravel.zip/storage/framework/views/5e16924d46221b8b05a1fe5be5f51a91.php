<div
   id="kt_app_sidebar"
   class="app-sidebar flex-column"
   data-kt-drawer="true"
   data-kt-drawer-name="app-sidebar"
   data-kt-drawer-activate="{default: true, lg: false}"
   data-kt-drawer-overlay="true"
   data-kt-drawer-width="225px"
   data-kt-drawer-direction="start"
   data-kt-drawer-toggle="#kt_app_sidebar_mobile_toggle">
   <!--begin::Logo-->
   <div class="app-sidebar-logo px-6" id="kt_app_sidebar_logo">
      <!--begin::Logo image-->
      <a href="<?php echo e(route('dashboard')); ?>">
         <img alt="Logo" src="<?php echo e(asset('assets/img/rean-hitam-putiih.png')); ?>" class="h-25px app-sidebar-logo-default ms-3" />
         <img alt="Logo" src="<?php echo e(asset('assets/img/rean-logo-hitam-putih.png')); ?>" class="h-25px app-sidebar-logo-minimize" />
      </a>
      <!--end::Logo image-->
      <!--begin::Sidebar toggle-->
      <!--begin::Minimized sidebar setup:
                        if (isset($_COOKIE["sidebar_minimize_state"]) && $_COOKIE["sidebar_minimize_state"] === "on") {
                           1. "src/js/layout/sidebar.js" adds "sidebar_minimize_state" cookie value to save the sidebar minimize state.
                           2. Set data-kt-app-sidebar-minimize="on" attribute for body tag.
                           3. Set data-kt-toggle-state="active" attribute to the toggle element with "kt_app_sidebar_toggle" id.
                           4. Add "active" class to to sidebar toggle element with "kt_app_sidebar_toggle" id.
                        }
                        -->
      <div
         id="kt_app_sidebar_toggle"
         class="app-sidebar-toggle btn btn-icon btn-shadow btn-sm btn-color-muted btn-active-color-primary body-bg h-30px w-30px position-absolute top-50 start-100 translate-middle rotate"
         data-kt-toggle="true"
         data-kt-toggle-state="active"
         data-kt-toggle-target="body"
         data-kt-toggle-name="app-sidebar-minimize">
         <i class="ki-duotone ki-double-left fs-2 rotate-180"><span class="path1"></span><span class="path2"></span></i>
      </div>
      <!--end::Sidebar toggle-->
   </div>
   <!--end::Logo-->
   <!--begin::sidebar menu-->
   <div class="app-sidebar-menu overflow-hidden flex-column-fluid">
      <!--begin::Menu wrapper-->
      <div
         id="kt_app_sidebar_menu_wrapper"
         class="app-sidebar-wrapper hover-scroll-overlay-y my-5"
         data-kt-scroll="true"
         data-kt-scroll-activate="true"
         data-kt-scroll-height="auto"
         data-kt-scroll-dependencies="#kt_app_sidebar_logo, #kt_app_sidebar_footer"
         data-kt-scroll-wrappers="#kt_app_sidebar_menu"
         data-kt-scroll-offset="5px"
         data-kt-scroll-save-state="true">
         <!--begin::Menu-->
         <div class="menu menu-column menu-rounded menu-sub-indention px-3" id="#kt_app_sidebar_menu" data-kt-menu="true" data-kt-menu-expand="false">
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item here show menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-element-11 fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></i>
                  </span>
                  <span class="menu-title">Dashboards</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link active" href="index.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Default</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="dashboards/ecommerce.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">eCommerce</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="dashboards/projects.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Projects</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="dashboards/online-courses.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Online Courses</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="dashboards/marketing.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Marketing</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <div class="menu-inner flex-column collapse" id="kt_app_sidebar_menu_dashboards_collapse">
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/bidding.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Bidding</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/pos.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">POS System</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/call-center.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Call Center</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/logistics.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Logistics</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/website-analytics.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Website Analytics</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/finance-performance.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Finance Performance</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/store-analytics.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Store Analytics</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/social.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Social</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/delivery.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Delivery</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/crypto.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Crypto</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/school.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">School</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="dashboards/podcast.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Podcast</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                     <!--begin:Menu item-->
                     <div class="menu-item">
                        <!--begin:Menu link-->
                        <a class="menu-link" href="landing.html">
                           <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Landing</span>
                        </a>
                        <!--end:Menu link-->
                     </div>
                     <!--end:Menu item-->
                  </div>
                  <div class="menu-item">
                     <div class="menu-content">
                        <a
                           class="btn btn-flex btn-color-primary d-flex flex-stack fs-base p-0 ms-2 mb-2 toggle collapsible collapsed"
                           data-bs-toggle="collapse"
                           href="#kt_app_sidebar_menu_dashboards_collapse"
                           data-kt-toggle-text="Show Less">
                           <span data-kt-toggle-text-target="true">Show 12 More</span> <i class="ki-duotone ki-minus-square toggle-on fs-2 me-0"><span class="path1"></span><span
                                 class="path2"></span></i>
                           <i class="ki-duotone ki-plus-square toggle-off fs-2 me-0"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                        </a>
                     </div>
                  </div>
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item pt-5">
               <!--begin:Menu content-->
               <div class="menu-content"><span class="menu-heading fw-bold text-uppercase fs-7">Pages</span></div>
               <!--end:Menu content-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-address-book fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                  </span>
                  <span class="menu-title">User Profile</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/user-profile/overview.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Overview</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/user-profile/projects.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Projects</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/user-profile/campaigns.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Campaigns</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/user-profile/documents.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Documents</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/user-profile/followers.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Followers</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/user-profile/activity.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Activity</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-element-plus fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span
                           class="path5"></span></i>
                  </span>
                  <span class="menu-title">Account</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/overview.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Overview</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/settings.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Settings</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/security.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Security</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/activity.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Activity</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/billing.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Billing</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/statements.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Statements</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/referrals.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Referrals</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/api-keys.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">API Keys</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="account/logs.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Logs</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-user fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Authentication</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Corporate Layout</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion menu-active-bg">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/corporate/sign-in.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-in</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/corporate/sign-up.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-up</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/corporate/two-factor.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Two-Factor</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/corporate/reset-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reset Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/corporate/new-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Overlay Layout</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion menu-active-bg">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/overlay/sign-in.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-in</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/overlay/sign-up.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-up</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/overlay/two-factor.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Two-Factor</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/overlay/reset-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reset Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/overlay/new-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Creative Layout</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion menu-active-bg">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/creative/sign-in.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-in</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/creative/sign-up.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-up</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/creative/two-factor.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Two-Factor</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/creative/reset-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reset Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/creative/new-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Fancy Layout</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion menu-active-bg">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/fancy/sign-in.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-in</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/fancy/sign-up.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sign-up</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/fancy/two-factor.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Two-Factor</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/fancy/reset-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reset Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/layouts/fancy/new-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Email Templates</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion menu-active-bg">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/welcome-message.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Welcome Message</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/reset-password.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reset Password</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/subscription-confirmed.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Subscription Confirmed</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/card-declined.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Credit Card Declined</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/promo-1.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Promo 1</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/promo-2.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Promo 2</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="authentication/email/promo-3.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Promo 3</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/extended/multi-steps-sign-up.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Multi-steps Sign-up</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/welcome.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Welcome Message</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/verify-email.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Verify Email</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/coming-soon.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Coming Soon</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/password-confirmation.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Password Confirmation</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/account-deactivated.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Account Deactivation</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/error-404.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Error 404</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="authentication/general/error-500.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Error 500</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="{default: 'click', lg: 'hover'}" data-kt-menu-placement="right-start" class="menu-item menu-lg-down-accordion menu-sub-lg-down-indention">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-file fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Corporate</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-lg-down-accordion menu-sub-lg-dropdown px-2 py-4 w-200px mh-75 overflow-auto">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/about.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">About</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/team.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Our Team</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/contact.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Contact Us</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/licenses.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Licenses</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/sitemap.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sitemap</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-39 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Social</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/social/feeds.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Feeds</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/social/activity.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Activty</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/social/followers.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Followers</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/social/settings.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Settings</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-bank fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Blog</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion menu-active-bg">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/blog/home.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Blog Home</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/blog/post.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Blog Post</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-chart-pie-3 fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                  </span>
                  <span class="menu-title">FAQ</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion menu-active-bg">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/faq/classic.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">FAQ Classic</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/faq/extended.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">FAQ Extended</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-bucket fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></i>
                  </span>
                  <span class="menu-title">Pricing</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion menu-active-bg">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/pricing/column.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Column Pricing</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/pricing/table.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Table Pricing</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-call fs-2">
                        <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span
                           class="path6"></span><span class="path7"></span>
                        <span class="path8"></span>
                     </i>
                  </span>
                  <span class="menu-title">Careers</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/careers/list.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Careers List</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="pages/careers/apply.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Careers Apply</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-color-swatch fs-2">
                        <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span
                           class="path6"></span><span class="path7"></span>
                        <span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span><span
                           class="path13"></span><span class="path14"></span>
                        <span class="path15"></span><span class="path16"></span><span class="path17"></span><span class="path18"></span><span class="path19"></span><span
                           class="path20"></span><span class="path21"></span>
                     </i>
                  </span>
                  <span class="menu-title">Utilities</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Modals</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                           <!--begin:Menu link-->
                           <span class="menu-link">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">General</span><span class="menu-arrow"></span>
                           </span>
                           <!--end:Menu link-->
                           <!--begin:Menu sub-->
                           <div class="menu-sub menu-sub-accordion menu-active-bg">
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/general/invite-friends.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Invite Friends</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/general/view-users.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Users</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/general/select-users.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Select Users</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/general/upgrade-plan.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Upgrade Plan</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/general/share-earn.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Share & Earn</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                           </div>
                           <!--end:Menu sub-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                           <!--begin:Menu link-->
                           <span class="menu-link">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Forms</span><span class="menu-arrow"></span>
                           </span>
                           <!--end:Menu link-->
                           <!--begin:Menu sub-->
                           <div class="menu-sub menu-sub-accordion menu-active-bg">
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/forms/new-target.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Target</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/forms/new-card.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Card</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/forms/new-address.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">New Address</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/forms/create-api-key.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create API Key</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/forms/bidding.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Bidding</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                           </div>
                           <!--end:Menu sub-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                           <!--begin:Menu link-->
                           <span class="menu-link">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Wizards</span><span class="menu-arrow"></span>
                           </span>
                           <!--end:Menu link-->
                           <!--begin:Menu sub-->
                           <div class="menu-sub menu-sub-accordion menu-active-bg">
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/create-app.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create App</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/create-campaign.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Campaign</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/create-account.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Business Acc</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/create-project.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Project</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/top-up-wallet.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Top Up Wallet</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/offer-a-deal.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Offer a Deal</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/wizards/two-factor-authentication.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Two Factor Auth</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                           </div>
                           <!--end:Menu sub-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                           <!--begin:Menu link-->
                           <span class="menu-link">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Search</span><span class="menu-arrow"></span>
                           </span>
                           <!--end:Menu link-->
                           <!--begin:Menu sub-->
                           <div class="menu-sub menu-sub-accordion menu-active-bg">
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/search/users.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Users</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                              <!--begin:Menu item-->
                              <div class="menu-item">
                                 <!--begin:Menu link-->
                                 <a class="menu-link" href="utilities/modals/search/select-location.html">
                                    <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Select Location</span>
                                 </a>
                                 <!--end:Menu link-->
                              </div>
                              <!--end:Menu item-->
                           </div>
                           <!--end:Menu sub-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Search</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/search/horizontal.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Horizontal</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/search/vertical.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Vertical</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/search/users.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Users</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/search/select-location.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Location</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Wizards</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/horizontal.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Horizontal</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/vertical.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Vertical</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/two-factor-authentication.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Two Factor Auth</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/create-app.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create App</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/create-campaign.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Campaign</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/create-account.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Account</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/create-project.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Project</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/modals/wizards/top-up-wallet.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Top Up Wallet</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="utilities/wizards/offer-a-deal.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Offer a Deal</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-element-7 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Widgets</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="widgets/lists.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Lists</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="widgets/statistics.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Statistics</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="widgets/charts.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Charts</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="widgets/mixed.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Mixed</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="widgets/tables.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Tables</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="widgets/feeds.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Feeds</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item pt-5">
               <!--begin:Menu content-->
               <div class="menu-content"><span class="menu-heading fw-bold text-uppercase fs-7">Apps</span></div>
               <!--end:Menu content-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-41 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Projects</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/list.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">My Projects</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/project.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Project</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/targets.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Targets</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/budget.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Budget</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/users.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Users</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/files.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Files</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/activity.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Activity</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/projects/settings.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Settings</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-basket fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></i>
                  </span>
                  <span class="menu-title">eCommerce</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Catalog</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/catalog/products.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Products</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/catalog/categories.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Categories</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/catalog/add-product.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Add Product</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/catalog/edit-product.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Edit Product</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/catalog/add-category.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Add Category</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/catalog/edit-category.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Edit Category</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sales</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/sales/listing.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Orders Listing</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/sales/details.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Order Details</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/sales/add-order.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Add Order</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/sales/edit-order.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Edit Order</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Customers</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/customers/listing.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Customer Listing</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/customers/details.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Customer Details</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reports</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/reports/view.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Products Viewed</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/reports/sales.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Sales</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/reports/returns.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Returns</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/reports/customer-orders.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Customer Orders</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/ecommerce/reports/shipping.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Shipping</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/ecommerce/settings.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Settings</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-25 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Contacts</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/contacts/getting-started.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Getting Started</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/contacts/add-contact.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Add Contact</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/contacts/edit-contact.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Edit Contact</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/contacts/view-contact.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Contact</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-chart fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Support Center</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/support-center/overview.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Overview</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion mb-1">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Tickets</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/support-center/tickets/list.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Tickets List</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/support-center/tickets/view.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Ticket</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion mb-1">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Tutorials</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/support-center/tutorials/list.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Tutorials List</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/support-center/tutorials/post.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Tutorial Post</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/support-center/faq.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">FAQ</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/support-center/licenses.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Licenses</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/support-center/contact.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Contact Us</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-28 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">User Management</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion mb-1">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Users</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/user-management/users/list.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Users List</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/user-management/users/view.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View User</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Roles</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/user-management/roles/list.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Roles List</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/user-management/roles/view.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Role</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/user-management/permissions.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Permissions</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-38 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Customers</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/customers/getting-started.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Getting Started</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/customers/list.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Customer Listing</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/customers/view.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Customer Details</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-map fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                  </span>
                  <span class="menu-title">Subscription</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/subscriptions/getting-started.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Getting Started</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/subscriptions/list.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Subscription List</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/subscriptions/add.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Add Subscription</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/subscriptions/view.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Subscription</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-credit-cart fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Invoice Manager</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
                     <!--begin:Menu link-->
                     <span class="menu-link">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View Invoices</span><span class="menu-arrow"></span>
                     </span>
                     <!--end:Menu link-->
                     <!--begin:Menu sub-->
                     <div class="menu-sub menu-sub-accordion menu-active-bg">
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/invoices/view/invoice-1.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Invoice 1</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/invoices/view/invoice-2.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Invoice 2</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                        <!--begin:Menu item-->
                        <div class="menu-item">
                           <!--begin:Menu link-->
                           <a class="menu-link" href="apps/invoices/view/invoice-3.html">
                              <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Invoice 3</span>
                           </a>
                           <!--end:Menu link-->
                        </div>
                        <!--end:Menu item-->
                     </div>
                     <!--end:Menu sub-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/invoices/create.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Create Invoice</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-switch fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">File Manager</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/file-manager/folders.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Folders</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/file-manager/files.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Files</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/file-manager/blank.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Blank Directory</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/file-manager/settings.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Settings</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-sms fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Inbox</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/inbox/listing.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Messages</span><span class="menu-badge"><span
                              class="badge badge-success">3</span></span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/inbox/compose.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Compose</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/inbox/reply.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">View & Reply</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-message-text-2 fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
                  </span>
                  <span class="menu-title">Chat</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/chat/private.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Private Chat</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/chat/group.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Group Chat</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="apps/chat/drawer.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Drawer Chat</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item">
               <!--begin:Menu link-->
               <a class="menu-link" href="apps/calendar.html">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-calendar-8 fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span
                           class="path5"></span><span class="path6"></span></i>
                  </span>
                  <span class="menu-title">Calendar</span>
               </a>
               <!--end:Menu link-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item pt-5">
               <!--begin:Menu content-->
               <div class="menu-content"><span class="menu-heading fw-bold text-uppercase fs-7">Layouts</span></div>
               <!--end:Menu content-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-element-7 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Layout Options</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="layouts/light-sidebar.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Light Sidebar</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="layouts/dark-sidebar.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Dark Sidebar</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="layouts/light-header.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Light Header</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="layouts/dark-header.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Dark Header</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div data-kt-menu-trigger="click" class="menu-item menu-accordion">
               <!--begin:Menu link-->
               <span class="menu-link">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-text-align-center fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></i>
                  </span>
                  <span class="menu-title">Toolbars</span><span class="menu-arrow"></span>
               </span>
               <!--end:Menu link-->
               <!--begin:Menu sub-->
               <div class="menu-sub menu-sub-accordion">
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="toolbars/classic.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Classic</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="toolbars/saas.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">SaaS</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="toolbars/accounting.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Accounting</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="toolbars/extended.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Extended</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
                  <!--begin:Menu item-->
                  <div class="menu-item">
                     <!--begin:Menu link-->
                     <a class="menu-link" href="toolbars/reports.html">
                        <span class="menu-bullet"><span class="bullet bullet-dot"></span></span><span class="menu-title">Reports</span>
                     </a>
                     <!--end:Menu link-->
                  </div>
                  <!--end:Menu item-->
               </div>
               <!--end:Menu sub-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item">
               <!--begin:Menu link-->
               <a class="menu-link" href="layout-builder.html">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-13 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Layout Builder</span>
               </a>
               <!--end:Menu link-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item pt-5">
               <!--begin:Menu content-->
               <div class="menu-content"><span class="menu-heading fw-bold text-uppercase fs-7">Help</span></div>
               <!--end:Menu content-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item">
               <!--begin:Menu link-->
               <a class="menu-link" href="https://preview.keenthemes.com/html/metronic/docs/base/utilities" target="_blank">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-rocket fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Components</span>
               </a>
               <!--end:Menu link-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item">
               <!--begin:Menu link-->
               <a class="menu-link" href="https://preview.keenthemes.com/html/metronic/docs" target="_blank">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-abstract-26 fs-2"><span class="path1"></span><span class="path2"></span></i>
                  </span>
                  <span class="menu-title">Documentation</span>
               </a>
               <!--end:Menu link-->
            </div>
            <!--end:Menu item-->
            <!--begin:Menu item-->
            <div class="menu-item">
               <!--begin:Menu link-->
               <a class="menu-link" href="https://preview.keenthemes.com/html/metronic/docs/getting-started/changelog" target="_blank">
                  <span class="menu-icon">
                     <i class="ki-duotone ki-code fs-2"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></i>
                  </span>
                  <span class="menu-title">Changelog v8.1.8</span>
               </a>
               <!--end:Menu link-->
            </div>
            <!--end:Menu item-->
         </div>
         <!--end::Menu-->
      </div>
      <!--end::Menu wrapper-->
   </div>
   <!--end::sidebar menu-->
   <!--begin::Footer-->
   <div class="app-sidebar-footer flex-column-auto pt-2 pb-6 px-6" id="kt_app_sidebar_footer">
      <a
         href="https://preview.keenthemes.com/html/metronic/docs"
         class="btn btn-flex flex-center btn-custom btn-primary overflow-hidden text-nowrap px-0 h-40px w-100"
         data-bs-toggle="tooltip"
         data-bs-trigger="hover"
         data-bs-dismiss-="click"
         title="200+ in-house components and 3rd-party plugins">
         <span class="btn-label">
            Docs & Components
         </span>
         <i class="ki-duotone ki-document btn-icon fs-2 m-0"><span class="path1"></span><span class="path2"></span></i>
      </a>
   </div>
   <!--end::Footer-->
</div>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard/template/partials/sidebar-old.blade.php ENDPATH**/ ?>