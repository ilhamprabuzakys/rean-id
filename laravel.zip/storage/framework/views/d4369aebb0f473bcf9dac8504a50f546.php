
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/components/datatable.blade.php ENDPATH**/ ?>