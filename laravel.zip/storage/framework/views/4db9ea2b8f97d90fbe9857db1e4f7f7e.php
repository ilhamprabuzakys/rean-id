<div class="sidebar-widget-area">
   <div class="title">
      <h5>Most Popular Videos</h5>
   </div>

   <div class="single-blog-post wow fadeInUpBig" data-wow-delay="0.2s">

      <div class="post-thumbnail">
         <img src="assets/Landing/world/img/blog-img/b7.jpg" alt="">

         <div class="post-cta"><a href="#">travel</a></div>

         <a href="https://www.youtube.com/watch?v=IhnqEwFSJRg" class="video-btn"><i class="fa fa-play"></i></a>
      </div>

      <div class="post-content">
         <a href="#" class="headline">
            <h5>How Did van Gogh’s Turbulent Mind Depict One of the Most Complex Concepts in Physics?</h5>
         </a>
         <p>How Did van Gogh’s Turbulent Mind Depict One of the Most Complex Concepts in...</p>

         <div class="post-meta">
            <p><a href="#" class="post-author">Katy Liu</a> on <a href="#" class="post-date">Sep 29, 2017 at 9:48 am</a></p>
         </div>
      </div>
   </div>
</div><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/world/partials/content/popularvideo.blade.php ENDPATH**/ ?>