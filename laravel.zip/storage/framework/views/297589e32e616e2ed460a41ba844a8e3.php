<div class="sidebar-widget-area">
   <h5 class="title">Today’s Pick</h5>
   <div class="widget-content">

      <div class="single-blog-post todays-pick">

         <div class="post-thumbnail">
            <img src="assets/Landing/world/img/blog-img/b22.jpg" alt="">
         </div>

         <div class="post-content px-0 pb-0">
            <a href="#" class="headline">
               <h5>How Did van Gogh’s Turbulent Mind Depict One of the Most Complex Concepts in Physics?</h5>
            </a>
         </div>
      </div>
   </div>
</div><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/world/partials/content/todayspick.blade.php ENDPATH**/ ?>