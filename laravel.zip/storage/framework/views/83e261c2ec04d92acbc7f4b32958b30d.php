
<?php $__env->startPush('scripts'); ?>
   <script src="<?php echo e(asset('assets/borex/libs/ckeditor/ckeditor5-build-classic/build/ckeditor.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="card">
      <div class="card-body">
         <form action="<?php echo e(route('categories.update', $category)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row mb-3">
               <div class="col-lg-12">
                  <label for="name" class="form-label">Nama</label>
                  <input type="text"
                     class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" value="<?php echo e(old('name', $category->name)); ?>">
               </div>
            </div>
            <div class="row justify-content-end mx-1">
               <button class="btn btn-primary px-2">
                  <i class="fas fa-save fa-md me-2"></i>
                  Simpan Perubahan</button>
            </div>
         </form>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-borex.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/categories/edit.blade.php ENDPATH**/ ?>