
<?php $__env->startPush('scripts'); ?>
   <!-- swiper js -->
   <script src="<?php echo e(asset('assets/borex/libs/swiper/swiper-bundle.min.js')); ?>"></script>
   <!-- nouisliderribute js -->
   <script src="<?php echo e(asset('assets/borex/libs/nouislider/nouislider.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/borex/libs/wnumb/wNumb.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
   <!-- swiper css -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/borex/libs/swiper/swiper-bundle.min.css')); ?>">
   <!-- nouisliderribute css -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/borex/libs/nouislider/nouislider.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row">
      <div class="col-lg-12">
         <div class="card">
            <div class="card-body p-0">
               <div class="swiper-container slider rounded">
                  <div class="swiper-wrapper" dir="ltr">
                     <div class="swiper-slide p-4 rounded overflow-hidden ecommerce-slied-bg" style="background-image: url(<?php echo e(asset('assets/borex/images/auth-bg.jpg')); ?>);">
                        <div class="bg-overlay bg-dark"></div>
                        <div class="row justify-content-center">
                           <div class="col-xl-7 col-lg-11">
                              <div class="row align-items-center">
                                 <div class="col-md-7">
                                    <h3 class="mb-2 text-truncate text-white"><a href="#" class="text-white"><?php echo e($post->title); ?> </a></h3>
                                    
                                    <h2 class="mb-0 mt-4 text-white"><span class="font-size-20">Sebuah </span><b> <?php echo e($post->category->name); ?></b></h2>
                                    <div class="mt-4">
                                       <?php $__empty_1 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                          <span class="badge rounded-pill bg-soft-primary w-md p-2 font-size-16 text-decoration-none"><?php echo e($tag->name); ?></span>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                          <a class="btn btn-primary w-md waves-effect waves-light">Belum memiliki tag</a>
                                       <?php endif; ?>
                                       
                                    </div>
                                 </div>
                                 <div class="col-md-5">
                                    <div class="p-4">
                                       <img src="<?php echo e(asset('storage/' . $post->file_path)); ?>" class="img-fluid" alt="image-posts">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     
                  </div>

                  
               </div>


            </div>
         </div>
      </div>
   </div>

   <div class="row">
      <div class="col-lg-12">
         <div class="card">
            
            <div class="card-body">
               <div class="row mb-4 justify-content-between">
                  <div class="col-lg-7">
                     <h3 class="text-capitalize"><?php echo e($post->title); ?></h3>
                  </div>
                  <div class="col-lg-5">
                     <div class="d-flex justify-content-end">
                        
                        
                        <a href="<?php echo e(route('posts.index')); ?>">
                           <span class="badge rounded-pill bg-primary w-md p-2 font-size-16 text-decoration-none">Kembali <i class="bx bx-share ms-2"></i></span>
                        </a>
                     </div>
                  </div>
                  <div class="row my-2 justify-content-start">
                     <div>
                        <img src="<?php echo e(asset('storage/' . $post->file_path)); ?>" alt="image-postingan" class="img-fluid post-image-size">
                     </div>
                  </div>
                  <div class="row ms-1">
                     <?php $__empty_1 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-1 me-3">
                           <span class="badge rounded-pill bg-primary w-md p-1 font-size-16 text-decoration-none"><?php echo e($tag->name); ?></span>
                        </div>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        ''
                     <?php endif; ?>
                  </div>
                  <div class="row my-3">
                     <?php echo $post->body; ?>

                  </div>
               </div>



            </div>
         </div>
         <!-- end row -->


      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-borex.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/posts/show.blade.php ENDPATH**/ ?>