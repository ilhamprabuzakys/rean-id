
<?php
   $categoriesCount = cache()->remember('categoriesCount', now()->addDays(1), function () {
       return App\Models\Category::count();
   });
?>
<?php $__env->startPush('scripts'); ?>
   <?php echo $__env->make('dashboard-borex.components.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script>
      $(document).ready(function() {
         $('#categories-table').DataTable();
      });
   </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row align-items-center">
      <div class="col-md-6">
         <div class="mb-3">
            <h5 class="card-title">Total Kategori <span class="text-muted fw-normal ms-2"><?php echo e($categoriesCount); ?></span></h5>
         </div>
      </div>

      <div class="col-md-6">
         <div class="d-flex flex-wrap align-items-center justify-content-end gap-2 mb-3">
            <div>
               <a href="<?php echo e(route('index') . '/api/categories'); ?>" class="btn btn-danger"><i class="bx bx-detail me-1"></i> API </a>
               <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><i class="bx bx-plus me-1"></i> Buat Kategori</a>
            </div>
         </div>

      </div>
   </div>

   <div class="row">
      <div class="col-xl-12">
         <div class="card shadow-md">
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-sm mb-0" id="categories-table">

                     <thead class="table-light">
                        <tr>
                           <th>#</th>
                           <th>Nama</th>
                           <th>Slug</th>
                           <th>Jumlah Postingan</th>
                           <th>Dibuat</th>
                           <th>Detail</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <th scope="row"><?php echo e($loop->iteration); ?></th>
                              <td>
                                 <a href="<?php echo e(route('categories.show', $category)); ?>" class="text-decoration-none text-secondary"><?php echo e($category->name); ?></a>
                              </td>
                              <td><?php echo e($category->slug); ?></td>
                              <td><?php echo e($category->posts->count()); ?></td>
                              <td>
                                 <?php
                                    $currentTime = now();
                                    $updatedAt = $category->updated_at;
                                    
                                    $diffInSeconds = $currentTime->diffInSeconds($updatedAt);
                                    
                                    if ($diffInSeconds < 60) {
                                        echo 'Baru saja - ' . $diffInSeconds + 4 . ' detik yang lalu';
                                    } else {
                                        echo $updatedAt->format('l, d F Y - H:i:s');
                                    }
                                 ?>
                              </td>
                              <td>
                                 <a href="#" class="text-decoration-none text-uppercase" data-bs-toggle="modal" data-bs-target="#postinganKategori<?php echo e($category->slug); ?>">Lihat semua postingan</a>
                              </td>
                              <td>
                                 <div class="dropdown">
                                    <a class="text-muted dropdown-toggle font-size-18 px-2" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true">
                                       <i class="bx bx-dots-horizontal-rounded"></i>
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-end">
                                       <a class="dropdown-item text-success text-decoration-none" href="<?php echo e(route('categories.edit', $category)); ?>">
                                          Edit
                                       </a>
                                       <a class="text-danger text-decoration-none dropdown-item" href="<?php echo e(route('categories.destroy', $category)); ?>" data-confirm-delete="true">Delete</a>
                                    </div>
                                 </div>
                              </td>
                           </tr>
                           <?php $__env->startPush('modal'); ?>
                              
                              <?php echo $__env->make('dashboard-borex.categories.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <?php $__env->stopPush(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-borex.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/categories/index.blade.php ENDPATH**/ ?>