   <?php if(session('fails')): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
         <div class="d-flex align-items-center">
            <i class="bx bxs-badge-check me-2"></i>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <span><?php echo session('danger'); ?></span>
         </div>
      </div>
   <?php elseif(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
         <div class="d-flex align-items-center">
            <i class="bx bxs-badge-check me-2"></i>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <span><?php echo session('success'); ?></span>
         </div>
      </div>
   <?php elseif(session('status')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
         <div class="d-flex align-items-center">
            <i class="bx bxs-badge-check me-2"></i>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <span><?php echo session('status'); ?></span>
         </div>
      </div>
   <?php elseif(session('message')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
         <div class="d-flex align-items-center">
            <i class="bx bxs-badge-check me-2"></i>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <span><?php echo session('message'); ?></span>
         </div>
      </div>
   <?php endif; ?>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/components/session.blade.php ENDPATH**/ ?>