
<?php
   $logsCount = App\Models\EventLog::count();
?>
<?php $__env->startPush('scripts'); ?>
   <?php echo $__env->make('dashboard-borex.components.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script>
      $(document).ready(function() {
         var table = $('#logs-table').DataTable();
         $('#filter-category').on('change', function() {
            var category = $(this).val();

            if (category === "") {
               // Jika kategori "Semua" dipilih, hapus filter pada kolom "Kategori"
               table.column(3).search("").draw();
            } else {
               // Jika kategori spesifik dipilih, terapkan filter pada kolom "Kategori"
               table.column(3).search(category).draw();
            }
         });
      });
   </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row align-items-center">
      <div class="col-md-6">
         <div class="mb-3">
            <h5 class="card-title">Total Log <span class="text-muted fw-normal ms-2"><?php echo e($logsCount); ?></span></h5>
         </div>
      </div>

      <div class="col-md-6">
         <div class="d-flex flex-wrap align-items-center justify-content-end gap-2 mb-3">
            <div>
               <a href="<?php echo e(route('index') . '/api/logs'); ?>" class="btn btn-danger"><i class="bx bx-detail me-1"></i> API </a>
            </div>
         </div>

      </div>
   </div>

   <div class="row">
      <div class="col-xl-12">
         <div class="card shadow-md">
            <div class="card-body">
               <div class="table-responsive">
                  
                  <table class="table table-sm mb-0" id="logs-table">

                     <thead class="table-light">
                        <tr>
                           <th>#</th>
                           <th>Event</th>
                           <th class="text-center">On</th>
                           <th>Subject</th>
                           <th>Oleh</th>
                           <th>Terakhir diupdate</th>
                           
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <th scope="row"><?php echo e($loop->iteration); ?></th>
                              <td>
                                 <?php echo e($log->event); ?>

                              </td>
                              <td class="text-center">
                                 <?php echo e($log->subject_type); ?>

                              </td>
                              <td>
                                 <?php if(!$log->subject->name): ?>
                                    <?php echo e($log->subject->title); ?>

                                 <?php else: ?>
                                    <?php echo e($log->subject->name); ?>

                                 <?php endif; ?>
                              </td>
                              <td>
                                 <?php if($log->user): ?>
                                 <?php echo e($log->user->name); ?>

                                 <?php if($log->user->username == auth()->user()->username): ?>
                                 <span class="text-primary"><?php echo e(__(' (Anda)')); ?></span>
                                 <?php endif; ?>
                                 <?php else: ?>
                                    <?php echo e(__('Faker')); ?>

                                 <?php endif; ?>
                              </td>
                              <td>
                                 <?php
                                    $currentTime = now();
                                    $updatedAt = $log->updated_at;
                                    
                                    $diffInSeconds = $currentTime->diffInSeconds($updatedAt);
                                    
                                    if ($diffInSeconds < 60) {
                                        echo 'Baru saja - ' . $diffInSeconds + 4 . ' detik yang lalu';
                                    } else {
                                        echo $updatedAt->format('l, d F Y - H:i:s');
                                    }
                                 ?>
                              </td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-borex.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/logs/index.blade.php ENDPATH**/ ?>