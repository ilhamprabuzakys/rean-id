<!--  Large modal example -->
<div class="modal fade" id="postinganDenganID<?php echo e($post->id); ?>" tabindex="-1" role="dialog">
   <div class="modal-dialog modal-dialog-scrollable modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="postinganDenganID<?php echo e($post->id); ?>"><?php echo e($post->category->name . ' ' . $post->title); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <div class="card">
               <?php if($post->category->name == 'Foto' && in_array(pathinfo($post->file_path, PATHINFO_EXTENSION), ['jpeg', 'jpg', 'png'])): ?>
                  <img class="post-image-size-modal" src="<?php echo e(asset('storage/' . $post->file_path)); ?>" alt="Title">
               <?php endif; ?>
               <div class="card-body">
                  <div class="row justify-content-between">
                     <div class="col-lg-8 d-flex align-items-center">
                        <h2><?php echo e($post->title); ?></h2>
                     </div>
                     <div class="col-lg-4 d-flex align-items-center justify-content-end">
                        <div> <span class="badge badge-soft-success w-md p-1 font-size-14 text-decoration-none"><?php echo e($post->category->name); ?></span></div>
                     </div>
                  </div>
                  <div class="row justify-content-start mt-2 mb-3">
                     <?php $__empty_1 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-2">
                           <span class="badge bg-primary w-md p-1 font-size-14 text-decoration-none"><?php echo e($tag->name); ?></span>
                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        ''
                     <?php endif; ?>
                  </div>
                  <p class="card-text"><?php echo $post->body; ?></p>
               </div>
            </div>
         </div>
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/posts/modal.blade.php ENDPATH**/ ?>