
<?php
   $postRelated = \App\Models\Post::where('category_id', $post->category->id)->get();
?>
<?php $__env->startPush('script'); ?>
   <script id="dsq-count-scr" src="//ilahazs.disqus.com/count.js" async></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row justify-content-center">
      <div class="col-12 col-lg-12">
         <div class="single-blog-content mb-2">
            <div class="row justify-content-between">
               <div class="col-12">
                  <h4><?php echo e($post->title); ?></h4>
               </div>
               <div class="col-12">
                  <p>
                     Oleh
                     <a href="#" class="post-author"><?php echo e($post->user->name); ?></a>
                     pada
                     <a href="#" class="post-date"><?php echo e($post->updated_at->format('M d, Y \a\t g:i a')); ?></a>
                  </p>
               </div>
            </div>


            <div class="post-content">
               <?php echo $post->body; ?>


               <div class="row mt-3">
                  <div class="col-8">
                     <p>
                        <span>Author: <a href="#" class="text-primary"><?php echo e($post->user->name); ?></a></span>
                        pada
                        <a href="#" class="post-date"><?php echo e($post->updated_at->format('M d, Y \a\t g:i a')); ?></a>
                     </p>
                  </div>
                  <div class="col-4 d-flex justify-content-end">
                     <p>
                        <span>Kategori: <a href="#" class="text-primary"><?php echo e($post->category->name); ?></a></span>
                     </p>
                  </div>
                  <?php if($post->tags != null): ?>
                     <div class="col-12">
                        <p>
                           <span>Tags:
                              <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <a href="#" class="text-primary">#<?php echo e($tag->name); ?></a>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </span>
                        </p>
                     </div>
                  <?php endif; ?>
               </div>
            </div>

            <div class="row mt-3">
               <div class="col-lg-12">
                  <div class="card px-0 shadow-sm">
                     <div class="card-body">
                        <div id="disqus_thread"></div>
                     </div>
                  </div>
                  <script>
                     /**
                      *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
                      *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
                     /*
                     var disqus_config = function () {
                     this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
                     this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
                     };
                     */
                     (function() { // DON'T EDIT BELOW THIS LINE
                        var d = document,
                           s = d.createElement('script');
                        s.src = 'https://rean-id.disqus.com/embed.js';
                        s.setAttribute('data-timestamp', +new Date());
                        (d.head || d.body).appendChild(s);
                     })();
                  </script>
                  <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
               </div>
               
            </div>
         </div>

         

      


      <div class="row my-5">
         <?php $__currentLoopData = $postRelated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->iteration > 3): ?>
            <?php break; ?>
         <?php endif; ?>
         <div class="col-12 col-md-6 col-lg-4">
            <div class="single-blog-post">
               

               <div class="post-content">
                  <a href="#" class="headline">
                     <h5>
                        <?php echo e(Str::limit($post->title, 20, '')); ?>

                     </h5>
                  </a>
                  <p>
                     <?php echo e(Str::limit($post->body, 30)); ?>

                  </p>

                  <div class="post-meta">
                     <p>
                        <a href="#" class="post-author"><?php echo e($post->user->name); ?></a>
                        on
                        <a href="#" class="post-date"><?php echo e($post->updated_at->format('M d, Y \a\t g:i a')); ?></a>
                     </p>
                  </div>
               </div>
            </div>
         </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hero'); ?>
   <div
      class="hero-area height-700 bg-img background-overlay"
      style="background-image: url(assets/Landing/world/img/blog-img/bg-custom-1.jpg)">
      <div class="container h-100">
         <div
            class="row h-100 align-items-center justify-content-center">
            <div class="col-12 col-md-8 col-lg-6">
               <div class="single-blog-title text-center">
                  <div class="post-cta py-2"><a href="#"><?php echo e($heropost->category->name); ?></a></div>
                  <h3>
                     <?php echo e($heropost->title); ?>

                  </h3>
               </div>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.world.world', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/world/detail.blade.php ENDPATH**/ ?>