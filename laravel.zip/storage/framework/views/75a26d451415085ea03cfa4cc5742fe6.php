
<!doctype html>
<html lang="en">

    <head>
        
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Website Anti Narkoba" name="description" />
        <meta content="ReanID" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/img/rean-berwarna-logo-saja2.png')); ?>">

        <!-- Bootstrap Css -->
        <link href="<?php echo e(asset('assets/borex/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo e(asset('assets/borex/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo e(asset('assets/borex/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body class="bg-dark">
        <section class="authentication-bg min-vh-100 py-5 py-lg-0">
            <div class="bg-overlay bg-dark"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="text-center mb-5">
                                        <?php echo $__env->yieldContent('content'); ?>
                                        <div class="mt-5 text-center">
                                            <a class="btn btn-primary waves-effect waves-dark px-3 py-1" href="<?php echo e(route('dashboard')); ?>">Back to Dashboard</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('assets/borex/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/borex/libs/metismenujs/metismenujs.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/borex/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/borex/libs/eva-icons/eva.min.js')); ?>"></script>

    </body>
</html>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/layouts/error.blade.php ENDPATH**/ ?>