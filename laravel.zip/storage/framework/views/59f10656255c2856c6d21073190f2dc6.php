<div
   class="hero-area height-700 bg-img background-overlay"
   style="background-image: url(assets/Landing/world/img/blog-img/bg-custom-1.jpg)">
   <div class="container h-100">
      <div
         class="row h-100 align-items-center justify-content-center">
         <div class="col-12 col-md-8 col-lg-6">
            <div class="single-blog-title text-center">
               <div class="post-cta py-2"><a href="#"><?php echo e($post->category->name); ?></a></div>
               <h3>
                  <?php echo e($post->slug); ?>

               </h3>
            </div>
         </div>
      </div>
   </div>
</div>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/world/partials/hero/hero-detail.blade.php ENDPATH**/ ?>