<div class="my-2">
<?php echo $__env->make('components.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/auth/session.blade.php ENDPATH**/ ?>