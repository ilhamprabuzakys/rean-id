<?php
   // $postsCount = cache()->remember('postsCount', now()->addDays(1), function () {
   //     return App\Models\Post::count();
   // });
   // $categoriesCount = cache()->remember('categoriesCount', now()->addDays(1), function () {
   //     return App\Models\Category::count();
   // });
   // $usersCount = cache()->remember('usersCount', now()->addDays(1), function () {
   //    return App\Models\User::count();
   // });
?>
<div id="sidebar-menu">
   <!-- Left Menu Start -->
   <ul class="metismenu list-unstyled" id="side-menu">
      <li class="menu-title" data-key="t-menu">Menu</li>

      <li class="<?php echo e(Request::is('dashboard') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('dashboard')); ?>">
            <i class="icon nav-icon" data-eva="monitor-outline"></i>
            <span class="menu-item" data-key="t-dashboards">Dashboards</span>
         </a>
      </li>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('superadmin')): ?>

      

     <li class="menu-title" data-key="t-pages">Data Utama</li>

      <li class="<?php echo e(Request::is('post*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('posts.index')); ?>">
            <i class="icon nav-icon" data-eva="book-open-outline"></i>
            <span class="menu-item" data-key="t-posts">Posts</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($postsCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('posts.index')); ?>" data-key="t-posts-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('posts.create')); ?>" data-key="t-posts-add">Tambah Data</a></li>
        </ul>
      </li>

      <li class="<?php echo e(Request::is('categories*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('categories.index')); ?>">
            <i class="icon nav-icon" data-eva="external-link-outline"></i>
            <span class="menu-item" data-key="t-categories">Kategori</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($categoriesCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('categories.index')); ?>" data-key="t-categories-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('categories.create')); ?>" data-key="t-categories-add">Tambah Data</a></li>
        </ul>
      </li>
     
      <li class="<?php echo e(Request::is('tags*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('tags.index')); ?>">
            <i class="icon nav-icon" data-eva="pantone-outline"></i>
            <span class="menu-item" data-key="t-tags">Tag</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($tagsCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('tags.index')); ?>" data-key="t-tags-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('tags.create')); ?>" data-key="t-tags-add">Tambah Data</a></li>
        </ul>
      </li>

      <li class="menu-title" data-key="t-pages">Data Manajemen</li>

      <li class="<?php echo e(Request::is('posts/approval') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('posts.approval')); ?>">
            <i class="icon nav-icon" data-eva="checkmark-circle-outline"></i>
            <span class="menu-item" data-key="t-dashboards">Post Approval</span>
         </a>
      </li>

      <li class="<?php echo e(Request::is('users*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('users.index')); ?>">
            <i class="icon nav-icon" data-eva="people-outline"></i>
            <span class="menu-item" data-key="t-users">User</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($usersCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('users.index')); ?>" data-key="t-users-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('users.roles')); ?>" data-key="t-users-roles">Perizinan</a></li>
            <li><a href="<?php echo e(route('users.create')); ?>" data-key="t-users-add">Tambah Data</a></li>
        </ul>
      </li>

      <li class="<?php echo e(Request::is('log*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('logs.index')); ?>">
            <i class="icon nav-icon" data-eva="activity-outline"></i>
            <span class="menu-item" data-key="t-utility">Log</span>
         </a>
      </li> 
      
      <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
      <li class="menu-title" data-key="t-pages">Data Utama</li>

      <li class="<?php echo e(Request::is('post*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('posts.index')); ?>">
            <i class="icon nav-icon" data-eva="book-open-outline"></i>
            <span class="menu-item" data-key="t-posts">Posts</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($postsCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('posts.index')); ?>" data-key="t-posts-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('posts.create')); ?>" data-key="t-posts-add">Tambah Data</a></li>
        </ul>
      </li>

      <li class="menu-title" data-key="t-pages">Data Manajemen</li>

      <li class="<?php echo e(Request::is('posts/approval') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('posts.approval')); ?>">
            <i class="icon nav-icon" data-eva="checkmark-circle-outline"></i>
            <span class="menu-item" data-key="t-dashboards">Post Approval</span>
         </a>
      </li>
      
      <li class="<?php echo e(Request::is('users*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('users.index')); ?>">
            <i class="icon nav-icon" data-eva="people-outline"></i>
            <span class="menu-item" data-key="t-users">User</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($usersCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('users.index')); ?>" data-key="t-users-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('users.roles')); ?>" data-key="t-users-roles">Perizinan</a></li>
            <li><a href="<?php echo e(route('users.create')); ?>" data-key="t-users-add">Tambah Data</a></li>
        </ul>
      </li>

      <li class="<?php echo e(Request::is('log*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('logs.index')); ?>">
            <i class="icon nav-icon" data-eva="activity-outline"></i>
            <span class="menu-item" data-key="t-utility">Log</span>
         </a>
      </li> 
      <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member')): ?>
      <li class="menu-title" data-key="t-pages">Data Utama</li>

      <li class="<?php echo e(Request::is('post*') ? 'mm-active' : ''); ?>">
         <a href="<?php echo e(route('posts.index')); ?>">
            <i class="icon nav-icon" data-eva="book-open-outline"></i>
            <span class="menu-item" data-key="t-posts">Posts</span>
            <span class="badge rounded-pill badge-soft-primary" data-key="t-hot"><?php echo e($postsCount); ?></span>
         </a>
         <ul class="sub-menu" aria-expanded="false">
            <li><a href="<?php echo e(route('posts.index')); ?>" data-key="t-posts-all">Lihat semua</a></li>
            <li><a href="<?php echo e(route('posts.create')); ?>" data-key="t-posts-add">Tambah Data</a></li>
        </ul>
      </li>
      <?php endif; ?>
   </ul>
</div>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/layouts/components/sidebar.blade.php ENDPATH**/ ?>