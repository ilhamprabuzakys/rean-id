<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="description" content="">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <?php if($title == ''): ?>
      <title>REAN.ID - Anti Narkoba Cegah Narkoba</title>
   <?php else: ?>
      <title><?php echo e($title); ?> | REAN.ID - Anti Narkoba Cegah Narkoba</title>
   <?php endif; ?>

   <link rel="icon" href="<?php echo e(asset('assets/img/rean-berwarna-logo-saja2.png')); ?>">

   <?php echo $__env->make('landing.world.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body>

   <div id="preloader">
      <div class="preload-content">
         <div id="world-load"></div>
      </div>
   </div>


   <?php echo $__env->make('landing.world.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->yieldContent('hero'); ?>

   <div class="main-content-wrapper py-3">
      <div class="container">
         <?php echo $__env->yieldContent('content'); ?>
      </div>
   </div>

   <?php echo $__env->make('landing.world.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


   <?php echo $__env->make('landing.world.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/world/world.blade.php ENDPATH**/ ?>