<header id="page-topbar" class="ishorizontal-topbar">
   <div class="navbar-header">
      <div class="d-flex">
         <!-- LOGO -->
         <div class="navbar-brand-box">
            <a href="<?php echo e(route('dashboard')); ?>" class="logo logo-dark">
               <span class="logo-sm">
                  <img src="<?php echo e(asset('assets/img/rean-berwarna-logo-saja.png')); ?>" alt="" height="22">
               </span>
               <span class="logo-lg">
                  <img src="<?php echo e(asset('assets/img/rean-hitam-putiih.png')); ?>" alt="" height="22">
               </span>
            </a>

            <a href="<?php echo e(route('dashboard')); ?>" class="logo logo-light">
               <span class="logo-sm">
                  <img src="<?php echo e(asset('assets/img/rean-berwarna-logo-saja.png')); ?>" alt="" height="22">
               </span>
               <span class="logo-lg">
                  <img src="<?php echo e(asset('assets/img/rean-hitam-putiih.png')); ?>" alt="" height="22">
               </span>
            </a>
         </div>

         <button type="button" class="btn btn-sm px-3 font-size-16 d-lg-none header-item" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
            <i class="fa fa-fw fa-bars"></i>
         </button>

         <div class="d-none d-sm-block ms-2 align-self-center">
            <h4 class="page-title">Dashboard</h4>
         </div>
      </div>

      <div class="d-flex">
         <div class="dropdown">
            <button type="button" class="btn header-item"
               data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <i class="icon-sm" data-eva="search-outline"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end dropdown-menu-md p-0">
               <form class="p-2">
                  <div class="search-box">
                     <div class="position-relative">
                        <input type="text" class="form-control bg-light border-0" placeholder="Search...">
                        <i class="search-icon" data-eva="search-outline" data-eva-height="26" data-eva-width="26"></i>
                     </div>
                  </div>
               </form>
            </div>
         </div>

         <div class="dropdown d-inline-block">
            <button type="button" class="btn header-item noti-icon" id="page-header-notifications-dropdown"
               data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <i class="icon-sm" data-eva="bell-outline"></i>
               <span class="noti-dot bg-danger rounded-pill">4</span>
            </button>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
               aria-labelledby="page-header-notifications-dropdown">
               <div class="p-3">
                  <div class="row align-items-center">
                     <div class="col">
                        <h5 class="m-0 font-size-15"> Notifications </h5>
                     </div>
                     <div class="col-auto">
                        <a href="#!" class="small fw-semibold text-decoration-underline"> Mark all as read</a>
                     </div>
                  </div>
               </div>
               <div data-simplebar style="max-height: 250px;">
                  <a href="#!" class="text-reset notification-item">
                     <div class="d-flex">
                        <div class="flex-shrink-0 me-3">
                           <img src="<?php echo e(asset('assets/borex/images/users/avatar-3.jpg')); ?>" class="rounded-circle avatar-sm" alt="user-pic">
                        </div>
                        <div class="flex-grow-1">
                           <h6 class="mb-1">James Lemire</h6>
                           <div class="font-size-13 text-muted">
                              <p class="mb-1">It will seem like simplified English.</p>
                              <p class="mb-0"><i class="mdi mdi-clock-outline"></i> <span>1 hours ago</span></p>
                           </div>
                        </div>
                     </div>
                  </a>
                  <a href="#!" class="text-reset notification-item">
                     <div class="d-flex">
                        <div class="flex-shrink-0 avatar-sm me-3">
                           <span class="avatar-title bg-primary rounded-circle font-size-16">
                              <i class="bx bx-cart"></i>
                           </span>
                        </div>
                        <div class="flex-grow-1">
                           <h6 class="mb-1">Your order is placed</h6>
                           <div class="font-size-13 text-muted">
                              <p class="mb-1">If several languages coalesce the grammar</p>
                              <p class="mb-0"><i class="mdi mdi-clock-outline"></i> <span>3 min ago</span></p>
                           </div>
                        </div>
                     </div>
                  </a>
                  <a href="#!" class="text-reset notification-item">
                     <div class="d-flex">
                        <div class="flex-shrink-0 avatar-sm me-3">
                           <span class="avatar-title bg-success rounded-circle font-size-16">
                              <i class="bx bx-badge-check"></i>
                           </span>
                        </div>
                        <div class="flex-grow-1">
                           <h6 class="mb-1">Your item is shipped</h6>
                           <div class="font-size-13 text-muted">
                              <p class="mb-1">If several languages coalesce the grammar</p>
                              <p class="mb-0"><i class="mdi mdi-clock-outline"></i> <span>3 min ago</span></p>
                           </div>
                        </div>
                     </div>
                  </a>

                  <a href="#!" class="text-reset notification-item">
                     <div class="d-flex">
                        <div class="flex-shrink-0 me-3">
                           <img src="<?php echo e(asset('assets/borex/images/users/avatar-6.jpg')); ?>" class="rounded-circle avatar-sm" alt="user-pic">
                        </div>
                        <div class="flex-grow-1">
                           <h6 class="mb-1">Salena Layfield</h6>
                           <div class="font-size-13 text-muted">
                              <p class="mb-1">As a skeptical Cambridge friend of mine occidental.</p>
                              <p class="mb-0"><i class="mdi mdi-clock-outline"></i> <span>1 hours ago</span></p>
                           </div>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="p-2 border-top d-grid">
                  <a class="btn btn-sm btn-link font-size-14 btn-block text-center" href="javascript:void(0)">
                     <i class="uil-arrow-circle-right me-1"></i> <span>View More..</span>
                  </a>
               </div>
            </div>
         </div>

         <div class="dropdown d-inline-block">
            <button type="button" class="btn header-item noti-icon right-bar-toggle" id="right-bar-toggle">
               <i class="icon-sm" data-eva="settings-outline"></i>
            </button>
         </div>

         <div class="dropdown d-inline-block">
            <button type="button" class="btn header-item user text-start d-flex align-items-center" id="page-header-user-dropdown"
                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                
                <div>
                    <div class="avatar-title bg-soft-primary text-primary display-6 m-0 rounded-circle">
                        <i class="bx bxs-user-circle"></i>
                    </div>
                </div>
            </button>
            <div class="dropdown-menu dropdown-menu-end pt-0">
                <div class="p-3 border-bottom">
                    <h6 class="mb-0"><?php echo e(auth()->user()->name); ?></h6>
                    <p class="mb-0 font-size-11 text-muted"><?php echo e(auth()->user()->email); ?></p>
                </div>
                <a class="dropdown-item" href="<?php echo e(route('profile.index', auth()->user())); ?>">
                    
                    <i data-eva="person-outline" class="me-2 text-sm text-secondary fill-secondary"></i>
                    <span class="align-middle">Profile</span>
                </a>
                <div class="dropdown-divider"></div>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item bg-transparent border-0 text-muted">
                    <i data-eva="log-out-outline" class="me-2 text-sm text-secondary fill-secondary"></i>
                        
                        
                        <span
                          class="align-middle">Logout</span></button>
                 </form>
                
            </div>
        </div>
      </div>
   </div>
   <div class="topnav">
      <div class="container-fluid">
         <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

            <div class="collapse navbar-collapse" id="topnav-menu-content">
               <ul class="navbar-nav">
               </ul>
            </div>
         </nav>
      </div>
   </div>
</header>
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/layouts/components/sidebar-end.blade.php ENDPATH**/ ?>