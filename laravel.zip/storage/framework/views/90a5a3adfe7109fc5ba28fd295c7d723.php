
<?php $__env->startSection('title'); ?>
   404 Not Found
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <h1 class="error-title"> <span class="blink-infinite">404</span></h1>
   <h4 class="text-uppercase text-light">Halaman yang anda tuju tidak ditemukan</h4>
   <p class="font-size-15 mx-auto text-primary w-100 mt-3">"<?php echo e(request()->url()); ?>"</p>
   <p class="font-size-15 mx-auto text-light w-100 mt-0">Halaman yang anda kunjungi tidak ada atau mungkin sudah dihapus.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-borex.layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/errors/404.blade.php ENDPATH**/ ?>