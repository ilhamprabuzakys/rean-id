
<?php $__env->startSection('title'); ?>
   <h4 class="page-title">Dashboard</h4>
<?php $__env->stopSection(); ?>
<?php
   $postsCount = App\Models\Post::where('user_id', auth()->user()->id)
       ->get()
       ->count();
   $logsCount = App\Models\Log::where('user_id', auth()->user()->id)
       ->get()
       ->count();
   $usersCount = 0;
   if (auth()->user()->role != 'member') {
       $usersCount = App\Models\User::count();
   }
?>
<?php $__env->startSection('content'); ?>
   <div class="row">
      <div class="col-xxl-12">
         <div class="row d-flex justify-content-between">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-body">
                     <?php
                        $role = '';
                        switch (auth()->user()->role) {
                            case 'superadmin':
                                $role = 'Super Admin';
                                break;
                            case 'admin':
                                $role = 'Admin';
                                break;
                            case 'member':
                                $role = 'Member';
                                break;
                        }
                     ?>
                     <h2 class="card-title">Hai <?php echo e(auth()->user()->name); ?>! Kamu login sebagai <?php echo e($role); ?></h2>
                     <p class="card-text">Login pada <?php echo e(now()->format('l, d F Y')); ?> di Moh. Toha, Kota Bandung</p>
                     

                     <script>
                        // Mendapatkan lokasi pengguna
                        function getLocation() {
                           if (navigator.geolocation) {
                              navigator.geolocation.getCurrentPosition(showPosition);
                           } else {
                              console.log("Geolocation is not supported by this browser.");
                           }
                        }

                        // Menampilkan data lokasi
                        function showPosition(position) {
                           var latitude = position.coords.latitude;
                           var longitude = position.coords.longitude;

                           // Mengirim data lokasi ke server atau melakukan manipulasi lainnya
                           // ...

                           // Menampilkan data lokasi pada elemen dengan id 'user-location'
                           var userLocationElement = document.getElementById('user-location');
                           userLocationElement.textContent = 'Latitude: ' + latitude + ', Longitude: ' + longitude;
                        }

                        // Mengupdate waktu login setiap detik
                        setInterval(function() {
                           var loginTimeElement = document.getElementById('login-time');
                           loginTimeElement.textContent = new Date().toLocaleString();
                        }, 1000);

                        // Memanggil fungsi untuk mendapatkan lokasi pengguna saat halaman dimuat
                        getLocation();
                     </script>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-xxl-9">
         <div class="row d-flex justify-content-between">
            <?php if(auth()->user()->role != 'member'): ?>
               <div class="col-xl col-lg-auto">
                  <div class="card">
                     <div class="card-body">
                        <div class="d-flex align-items-center">
                           <div class="flex-shrink-0 me-3">
                              <div class="avatar">
                                 <div class="avatar-title rounded bg-primary bg-gradient">
                                    <i data-eva="people" class="fill-white"></i>
                                 </div>
                              </div>
                           </div>
                           <div class="flex-grow-1">
                              <p class="text-muted mb-1">Total Users</p>
                              <h4 class="mb-0"><?php echo e($usersCount); ?> User</h4>
                           </div>

                           
                        </div>
                     </div>
                     <!-- end card body -->
                  </div>
                  <!-- end card -->
               </div>
            <?php endif; ?>
            <div class="col-xl col-lg-auto">
               <div class="card">
                  <div class="card-body">
                     <div class="d-flex align-items-center">
                        <div class="flex-shrink-0 me-3">
                           <div class="avatar">
                              <div class="avatar-title rounded bg-warning bg-gradient">
                                 <i data-eva="book-open-outline" class="fill-white"></i>
                              </div>
                           </div>
                        </div>
                        <div class="flex-grow-1">
                           <p class="text-muted mb-1">Total Postingan</p>
                           <h4 class="mb-0"><?php echo e($postsCount); ?> <span class="h5">Postingan</span></h4>
                        </div>
                        <div class="flex-shrink-0 align-self-end ms-2">
                           <div class="badge rounded-pill font-size-13 badge-soft-danger">+3
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- end card body -->
               </div>
               <!-- end card -->
            </div>

            <div class="col-xl col-lg-auto">
               <div class="card">
                  <div class="card-body">
                     <div class="d-flex align-items-center">
                        <div class="flex-shrink-0 me-3">
                           <div class="avatar">
                              <div class="avatar-title rounded bg-success bg-gradient">
                                 <i data-eva="activity-outline" class="fill-white"></i>
                              </div>
                           </div>
                        </div>
                        <div class="flex-grow-1">
                           <p class="text-muted mb-1">Aktivitasku</p>
                           <h4 class="mb-0"><?php echo e($postsCount); ?> <span class="h5">Log aktivitas</span></h4>
                        </div>
                        
                     </div>
                  </div>
                  <!-- end card body -->
               </div>
               <!-- end card -->
            </div>
         </div>

         

         
      </div>
   </div>
   <!-- end row -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
   <!-- apexcharts -->
   <script src="<?php echo e(asset('assets/borex/libs/apexcharts/apexcharts.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/borex/js/pages/dashboard.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard-borex.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/basic/index.blade.php ENDPATH**/ ?>