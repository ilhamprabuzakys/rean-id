<!--begin::Global Javascript Bundle(mandatory for all pages)-->


<script src="<?php echo e(asset('assets/Metronic/preview.keenthemes.com/metronic8/demo1/assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/Metronic/preview.keenthemes.com/metronic8/demo1/assets/js/scripts.bundle.js')); ?>"></script>


<!--end::Global Javascript Bundle-->

<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard/template/partials/script.blade.php ENDPATH**/ ?>