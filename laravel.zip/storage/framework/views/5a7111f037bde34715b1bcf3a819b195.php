<div class="hero-area height-600" style="margin-bottom: 0px !important">

   <div class="hero-slides owl-carousel">

      <div class="single-hero-slide bg-img background-overlay" style="background-image: url(assets/Landing/world/img/blog-img/bg-custom-1.jpg);"></div>

      <div class="single-hero-slide bg-img background-overlay" style="background-image: url(assets/Landing/world/img/blog-img/bg1.jpg);"></div>
   </div>
   <?php
      $posts = \App\Models\Post::orderBy('updated_at', 'desc')->get();
   ?>
   <div class="hero-post-area">
      <div class="container border-danger">
         <div class="row">
            <div class="col-12">
               <img src="<?php echo e(asset('assets/img/rean-berwarna-logo-saja2.png')); ?>" alt="" class="logo-hero">
               <div class="hero-post-slide">
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($loop->iteration > 5): ?>
                     <?php break; ?>
                  <?php endif; ?>
                  <div class="single-slide d-flex align-items-center">
                     <div class="post-number">
                        <p><?php echo e($loop->iteration); ?></p>
                     </div>
                     <div class="post-title">
                        <a href="<?php echo e(route('home.show_post', $post)); ?>"><?php echo e($post->title); ?></a>
                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</div><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/landing/world/partials/hero.blade.php ENDPATH**/ ?>