
<?php
   $postsCount = App\Models\Post::count();
   $postsPendingCount = App\Models\Post::where('status', 'pending')->get()->count();
   $postsApprovedCount = App\Models\Post::where('status', 'approved')->get()->count();
   $postsRejectedCount = App\Models\Post::where('status', 'rejected')->get()->count();
?>
<?php $__env->startPush('scripts'); ?>
   <?php echo $__env->make('dashboard-borex.components.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script>
      $(document).ready(function() {
         var table = $('#posts-table').DataTable();
         $('#filter-category').on('change', function() {
            var category = $(this).val();

            if (category === "") {
               // Jika kategori "Semua" dipilih, hapus filter pada kolom "Kategori"
               table.column(3).search("").draw();
            } else {
               // Jika kategori spesifik dipilih, terapkan filter pada kolom "Kategori"
               table.column(3).search(category).draw();
            }
         });
         $('#filter-status').on('change', function() {
            var status = $(this).val();

            if (status === "") {
               table.column(4).search("").draw();
            } else {
               table.column(4).search(status).draw();
            }
         });
      });
   </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
   <div class="row align-items-center">
      <div class="col-md-5">
         <div class="mb-3">
            <h5 class="card-title">Total Postingan <span class="text-muted fw-normal ms-2"><?php echo e($postsCount); ?></span></h5>
         </div>
      </div>

      <div class="col-md-7">
         <div class="d-flex flex-wrap align-items-center justify-content-end gap-2 mb-3">
            <div>
               
                  <span class="card-title">Pending: <span class="text-primary fw-normal me-1"><?php echo e($postsPendingCount); ?></span></span>
                  <span class="card-title">Approved: <span class="text-success fw-normal me-1"><?php echo e($postsApprovedCount); ?></span></span>
                  <span class="card-title">Rejected: <span class="text-danger fw-normal me-1"><?php echo e($postsRejectedCount); ?></span></span>
            </div>
         </div>

      </div>
   </div>

   <div class="row">
      <div class="col-xl-12">
         <div class="card shadow-md">
            <div class="card-body">
               <div class="table-responsive">
                  <div class="row mb-3 justify-content-start">
                     <div class="col-lg-6">
                        <label for="filter-category" class="form-label">Kategori</label>
                        <select class="form-select form-select-md" name="category_id" id="filter-category">
                           <option selected value="">Semua</option>
                           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     </div>

                     <div class="col-lg-6">
                        <label for="filter-status" class="form-label">Status</label>
                        <select class="form-select form-select-md" name="status" id="filter-status">
                           <option selected value="">Semua</option>
                           <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($status->key); ?>"><?php echo e($status->label); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     </div>
                  </div>
                  <table class="table table-sm mb-0" id="posts-table">

                     <thead class="table-light">
                        <tr>
                           <th>#</th>
                           <th>Judul</th>
                           <th>Author</th>
                           <th class="text-center">Kategori</th>
                           <th>Status</th>
                           <th>Terakhir diupdate</th>
                           <th class="text-center">
                              <i class="bx bx bx-edit font-size-16"></i>
                           </th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           $postsCustom = '';
                           if (auth()->user()->role == 'member') {
                               $postsCustom = $posts->where('user_id', auth()->user()->id);
                           } else {
                               $postsCustom = $posts;
                           }
                        ?>
                        <?php $__currentLoopData = $postsCustom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <th scope="row"><?php echo e($loop->iteration); ?></th>
                              <td>
                                 <a href="<?php echo e(route('posts.show', $post)); ?>" class="text-decoration-none text-dark">
                                    <?php echo e($post->title); ?>

                                 </a>
                              </td>
                              <td><a href="<?php echo e(route('users.show', $post->user)); ?>" class="text-decoration-none text-dark">
                                    <?php echo e($post->user->name); ?>

                                    <?php if($post->user->username == auth()->user()->username): ?>
                                       <span class="text-primary"><?php echo e(__(' (Anda)')); ?></span>
                                    <?php endif; ?>
                                 </a></td>
                              <td class="text-center">
                                 <?php if($post->category): ?>
                                    <a href="<?php echo e(route('categories.show', $post->category)); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?></a>
                                 <?php else: ?>
                                    Belum diset
                                 <?php endif; ?>
                              </td>
                              <td class="text-center">
                                 <?php if($post->status == 'pending'): ?>
                                    <span class="badge badge-soft-primary">Pending</span>
                                 <?php elseif($post->status == 'approved'): ?>
                                    <span class="badge badge-soft-success">Approved</span>
                                 <?php else: ?>
                                    <span class="badge badge-soft-danger">Rejected</span>
                                 <?php endif; ?>
                              </td>
                              <td>
                                 <?php
                                    $currentTime = now();
                                    $updatedAt = $post->updated_at;
                                    
                                    $diffInSeconds = $currentTime->diffInSeconds($updatedAt);
                                    
                                    if ($diffInSeconds < 60) {
                                        echo 'Baru saja - ' . $diffInSeconds + 4 . ' detik yang lalu';
                                    } else {
                                        echo $updatedAt->format('l, d F Y - H:i:s');
                                    }
                                 ?>
                              </td>
                              <td class="text-center">
                                 <?php if($post->status != 'pending'): ?>
                                    <button type="button" disabled class="bg-transparent border-0">
                                       <?php if($post->status == 'approved'): ?>
                                          <span class="badge rounded-pill bg-approval opacity-50 p-2 font-size-12 text-decoration-none d-flex align-items-center">
                                             Approved
                                             <i class="bx bx-check-circle ms-2"></i>
                                          </span>
                                       <?php elseif($post->status == 'rejected'): ?>
                                          <span class="badge rounded-pill bg-reject opacity-50 p-2 font-size-12 text-decoration-none d-flex align-items-center">
                                             Rejected
                                             <i class="bx bx-x ms-2"></i>
                                          </span>
                                       <?php endif; ?>
                                    </button>

                                    <div class="dropdown">
                                       <a class="text-muted dropdown-toggle font-size-18 px-2" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true">
                                          <i class="bx bx-dots-horizontal-rounded"></i>
                                       </a>

                                       <div class="dropdown-menu dropdown-menu-end">
                                          <a class="dropdown-item text-decoration-none" href="#">
                                             <form action="<?php echo e(route('posts.approval.form')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                
                                                <input type="hidden" name="status" value="pending">
                                                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                                <button type="submit" class="bg-transparent border-0">
                                                <span class="text-primary">Revert to Pending</span>
                                                </button>
                                             </form>
                                          </a>
                                          <?php if($post->status == 'rejected'): ?>
                                             <a class="dropdown-item text-decoration-none" href="#">
                                                <form action="<?php echo e(route('posts.approval.form')); ?>" method="post">
                                                   <?php echo csrf_field(); ?>
                                                   
                                                   <input type="hidden" name="status" value="approved">
                                                   <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                                   <button type="submit" class="bg-transparent border-0">
                                                   <span class="text-success">Reject it</span>
                                                   </button>
                                                </form>
                                             </a>
                                          <?php elseif($post->status == 'approved'): ?>
                                             <a class="dropdown-item text-danger text-decoration-none" href="#">
                                                <form action="<?php echo e(route('posts.approval.form')); ?>" method="post">
                                                   <?php echo csrf_field(); ?>
                                                   
                                                   <input type="hidden" name="status" value="rejected">
                                                   <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                                   <button type="submit" class="bg-transparent border-0">
                                                   <span>Approve it</span>
                                                   </button>
                                                </form>
                                             </a>
                                          <?php endif; ?>
                                       </div>
                                    </div>
                                 <?php else: ?>
                                    <form action="<?php echo e(route('posts.approval.form')); ?>" method="post">
                                       <?php echo csrf_field(); ?>
                                       
                                       <input type="hidden" name="status" value="approved">
                                       <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

                                       <button type="submit" class="bg-transparent border-0">
                                          <span class="badge rounded-pill bg-approval p-2 font-size-12 text-decoration-none d-flex align-items-center">
                                             Approve?
                                             <i class="bx bx-check-circle font-size-14 ms-2"></i>
                                          </span>
                                       </button>
                                    </form>
                                    <form action="<?php echo e(route('posts.approval.form')); ?>" method="post">
                                       <?php echo csrf_field(); ?>
                                       
                                       <input type="hidden" name="status" value="rejected">
                                       <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

                                       <button type="submit" class="bg-transparent border-0">
                                          <span class="badge rounded-pill bg-reject p-2 font-size-12 text-decoration-none d-flex align-items-center">
                                             Reject?
                                             <i class="bx bx-x font-size-14 ms-2"></i>
                                          </span>
                                       </button>
                                    </form>
                                 <?php endif; ?>

                              </td>
                           </tr>
                           <?php $__env->startPush('modal'); ?>
                              <?php echo $__env->make('dashboard-borex.posts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <?php $__env->stopPush(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard-borex.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/posts/approval.blade.php ENDPATH**/ ?>