
<?php $__env->startSection('auth-content'); ?>
   <div class="text-center">
      <h4 class="mb-0">Welcome Back !</h4>
      <p class="text-muted mt-2"><?php echo e(__('Masuk dan gunakan aplikasi multifungsi ini!')); ?></p>
   </div>
   <?php echo $__env->make('auth.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <form class="mt-4 pt-2" action="<?php echo e(route('login.authenticate')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="form-floating form-floating-custom mb-4">
         <input type="text" class="form-control <?php echo e($errors->has('username') || $errors->has('email') ? ' is-invalid' : ''); ?> <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="input-username"
            placeholder="Enter User Name" name="login" value="<?php echo e(old('username') ?: old('email')); ?>" autofocus required>

         <?php if($errors->has('username') || $errors->has('email')): ?>
            <div class="invalid-feedback">
               <?php echo e($errors->first('username') ?: $errors->first('email')); ?>

            </div>
         <?php endif; ?>
         <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
               <?php echo e($errors->first('login')); ?>

            </div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         <label for="input-username">Username or Email</label>
         <div class="form-floating-icon">
            <i data-eva="people-outline"></i>
         </div>
      </div>

      <div class="form-floating form-floating-custom mb-4 auth-pass-inputgroup">
         <input type="password" class="form-control pe-5 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password-input" placeholder="Enter Password" autocomplete="on" name="password"
            value="<?php echo e(old('password')); ?>" required>
         <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
               <?php echo e($errors->first('password')); ?>

            </div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         
         <label for="input-password">Password</label>
         <div class="form-floating-icon">
            <i data-eva="lock-outline"></i>
         </div>
      </div>

      
   <div class="mt-1 mb-2 pb-2 text-center">
      <p class="text-muted mb-0">Forgotten your password ? <a href="<?php echo e(route('password.request')); ?>"
            class="text-primary fw-semibold"> Click here </a> </p>
   </div>

      <div class="mb-3">
         <button class="btn btn-primary w-100 waves-effect waves-light" type="submit">Log In</button>
      </div>
   </form>

   <div class="mt-4 pt-3 text-center">
      <p class="text-muted mb-0">Don't have an account ? <a href="<?php echo e(route('register')); ?>"
            class="text-primary fw-semibold"> Signup now </a> </p>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/auth/login.blade.php ENDPATH**/ ?>