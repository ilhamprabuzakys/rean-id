<!--  Large modal example -->
<div class="modal fade" id="postinganKategori<?php echo e($category->slug); ?>" tabindex="-1" role="dialog">
   <div class="modal-dialog modal-dialog-scrollable modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="postinganKategori<?php echo e($category->slug); ?>">Postingan dengan kategori <?php echo e($category->name); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <ul class="list-group">
               <?php
                  $posts = $category->posts()->orderBy('updated_at', 'desc')->get();
               ?>
               <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center">
                     <a href="<?php echo e(route('posts.show', $post)); ?>" class="text-decoration-none"><?php echo e($post->title); ?></a>
                     <span class="badge bg-success badge-pill"><?php echo e($post->user->name); ?></span>
                  </li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center">
                     Postingan dengan Kategori <?php echo e($category->name); ?> masih kosong!
                  </li>
               <?php endif; ?>
            </ul>
         </div>
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH /mnt/data/applications/web/2023/laravel-app/rean-id/resources/views/dashboard-borex/categories/modal.blade.php ENDPATH**/ ?>